from .calculator import *  # Se refiere a calculator.py
