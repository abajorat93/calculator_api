from .math_ops import *  # Se refiere al directorio (modulo)  math_ops
